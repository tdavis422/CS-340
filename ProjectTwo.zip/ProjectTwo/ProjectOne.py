from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    #initialization of connection to server for database access
    def __init__(self, **kwargs):
        USER = kwargs.get('USER')
        PASS = kwargs.get('PASS')
        HOST = 'nv-desktop-services.apporto.com' #host address to use for connection
        PORT = 31429 #port number to tunnel database info into server
        DB = 'AAC' #database that holds all the data
        COL = 'animals' #collection used to hold data required
        
        #connection variables
        self.client = MongoClient('mongodb://%s:%s@%s:%d/test?authSource=admin' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
    
    #create function for MongoDB
    def create(self, data):
        #as long as there is data held in the code
        if data is not None:
            insertDB = self.database.animals.insert_one(data) #used to determine if anything is added
            if insertDB != 0:
                return True
            else:
                return False

        #if there is no data, throw exception
        else:
            raise Exception("Nothing to save, data is empty")
            
    #read function for MongoDB
    def read(self, searchD):
        #if there is anything stored in searchD, look for it in database
        if searchD:
            data = self.database.animals.find(searchD, {"_id": False})
        #if searchD has nothing stored, return everything
        else:
            data = self.database.animals.find({}, {"_id": False})
        return data
    
    #update function for MongoDB
    def update(self, searchDB, updateDB):
        #if there is anything stored in searchDB, look and update when found
        if searchDB is not None:
            result = self.database.animals.update_many(searchDB, {"$set": updateDB})
        #if nothing, return empty
        else:
            return "{}"
        return result.raw_result
    
    #delete function for MongoDB
    def delete(self, deleteDB):
        #if anything stored in deleteDB, look and remove from database
        if deleteDB is not None:
            result = self.database.animals.delete_many(deleteDB)
        #if nothing, return empty
        else:
            return "{}"
        return result.raw_result